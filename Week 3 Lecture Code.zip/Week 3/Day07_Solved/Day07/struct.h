#pragma once
struct COLOR
{
	unsigned short red;
	unsigned short green;
	unsigned short blue;
	unsigned short alpha;
};