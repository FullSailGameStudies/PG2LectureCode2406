#pragma once


class rocketEngine final
{
public:
	virtual void ApplyThrust() final
	{ }
};

class carEngine// : public rocketEngine
{
public:
};
