#pragma once
class Calculator
{
public:
	//the declaration of the sum method
	int minus(int number1, int number2);

	static double mult(double num, double factor);
};

